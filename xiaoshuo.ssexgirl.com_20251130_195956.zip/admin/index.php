<?php
// admin/index.php - 修复变量未定义报错版
ini_set('display_errors', 1);
error_reporting(E_ALL ^ E_NOTICE);

require $_SERVER['DOCUMENT_ROOT'] . '/core/db.php';

if (!isset($_SESSION['admin_id'])) { header("Location: login.php"); exit; }

$current_tab = isset($_GET['tab']) ? $_GET['tab'] : 'dashboard';
$msg = '';

// === 1. 逻辑处理 ===
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['save_settings'])) {
    $pc = intval($_POST['home_layout_pc']);
    $mb = intval($_POST['home_layout_mb']);
    $conn->query("REPLACE INTO system_config (config_key, config_value) VALUES ('home_layout_pc', '$pc')");
    $conn->query("REPLACE INTO system_config (config_key, config_value) VALUES ('home_layout_mb', '$mb')");
    $msg = "✅ 设置已保存";
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_source'])) {
    $name = $conn->real_escape_string($_POST['name']);
    $type = $_POST['type'];
    $url = $conn->real_escape_string($_POST['api_url']);
    $sql = "INSERT INTO collect_sources (name, type, api_url) VALUES ('$name', '$type', '$url')";
    if($conn->query($sql)) { $msg = "✅ 添加成功"; $current_tab = 'sources'; }
}

if (isset($_GET['delete_source'])) {
    $id = intval($_GET['delete_source']);
    $conn->query("DELETE FROM collect_sources WHERE id=$id");
    echo "<script>location.href='?tab=sources';</script>";
}

// 生成卡密 (仅VIP)
if (isset($_POST['gen_cards'])) {
    $value = intval($_POST['value']);
    $num = intval($_POST['num']);
    if ($num > 0) {
        for ($i=0; $i<$num; $i++) {
            $code = strtoupper(substr(md5(uniqid(rand(),true)),0,16));
            $conn->query("INSERT INTO card_keys (code,type,value) VALUES ('$code','1','$value')");
        }
        $msg = "✅ 生成 {$num} 张VIP卡成功";
        $current_tab = 'cards';
    }
}

if (isset($_GET['del_card'])) {
    $id = intval($_GET['del_card']);
    $conn->query("DELETE FROM card_keys WHERE id=$id");
    echo "<script>location.href='?tab=cards';</script>";
}
if (isset($_GET['clear_used'])) {
    $conn->query("DELETE FROM card_keys WHERE status=1");
    echo "<script>alert('清理完成');location.href='?tab=cards';</script>";
}

// === 2. 数据读取 (修复点：确保变量存在) ===

// 采集源
$source_list = $conn->query("SELECT * FROM collect_sources ORDER BY id DESC");
$source_count = $source_list ? $source_list->num_rows : 0;

// 用户数 (先检查表)
$user_check = $conn->query("SHOW TABLES LIKE 'users'");
$user_count = ($user_check && $user_check->num_rows > 0) ? $conn->query("SELECT count(*) as c FROM users")->fetch_assoc()['c'] : 0;

// 卡密数 (修复这里：定义 $card_table_exists 变量供下面使用)
$card_table_check = $conn->query("SHOW TABLES LIKE 'card_keys'");
$card_table_exists = ($card_table_check && $card_table_check->num_rows > 0);

$card_count = 0;
if ($card_table_exists) {
    $c_res = $conn->query("SELECT count(*) as c FROM card_keys WHERE status=0");
    $card_count = $c_res ? $c_res->fetch_assoc()['c'] : 0;
}

$config = [];
$conf_res = $conn->query("SELECT * FROM system_config");
if ($conf_res) { while ($row = $conf_res->fetch_assoc()) $config[$row['config_key']] = $row['config_value']; }
$pc_val = $config['home_layout_pc'] ?? 4;
$mb_val = $config['home_layout_mb'] ?? 2;
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>后台管理</title>
    <link href="https://cdn.staticfile.org/bootstrap/5.1.3/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.staticfile.org/bootstrap-icons/1.8.1/font/bootstrap-icons.min.css">
    <style>
        body { background-color: #f4f6f9; font-family: "PingFang SC", sans-serif; overflow-x: hidden; }
        .sidebar { height: 100vh; position: fixed; top: 0; left: 0; width: 240px; background: #2c3e50; color: #fff; padding-top: 20px; z-index: 1000; }
        .nav-link { color: #b0b8c5; padding: 14px 25px; transition: 0.2s; text-decoration: none; display: block; }
        .nav-link:hover, .nav-link.active { color: #fff; background: rgba(255,255,255,0.1); border-left: 4px solid #0d6efd; }
        .main-content { margin-left: 240px; padding: 30px; }
        .card { border: none; border-radius: 12px; box-shadow: 0 4px 20px rgba(0,0,0,0.02); margin-bottom: 25px; background: #fff; }
        .stat-card { background: #fff; padding: 20px; border-radius: 12px; display: flex; align-items: center; justify-content: space-between; }
        .tab-section { display: none; }
        .active-section { display: block; }
        @media (max-width: 768px) {
            .sidebar { position: relative; width: 100%; height: auto; }
            .main-content { margin-left: 0; }
        }
    </style>
</head>
<body>

<div class="sidebar">
    <div class="text-center mb-4 fw-bold fs-5">🎬 管理后台</div>
    <div class="nav flex-column">
        <a class="nav-link <?php echo $current_tab=='dashboard'?'active':''; ?>" href="?tab=dashboard"><i class="bi bi-speedometer2 me-2"></i> 控制台</a>
        <a class="nav-link <?php echo $current_tab=='sources'?'active':''; ?>" href="?tab=sources"><i class="bi bi-cloud-download me-2"></i> 采集源</a>
        <a class="nav-link <?php echo $current_tab=='cards'?'active':''; ?>" href="?tab=cards"><i class="bi bi-credit-card me-2"></i> 卡密管理</a>
        <a class="nav-link <?php echo $current_tab=='users'?'active':''; ?>" href="?tab=users"><i class="bi bi-people me-2"></i> 用户列表</a>
        <div class="mt-4 px-3 small text-muted">SYSTEM</div>
        <a class="nav-link" href="/" target="_blank"><i class="bi bi-box-arrow-up-right me-2"></i> 访问前台</a>
        <a class="nav-link text-danger" href="?logout=1"><i class="bi bi-power me-2"></i> 退出</a>
    </div>
</div>

<div class="main-content">
    <?php if($msg): ?>
    <div class="alert alert-success alert-dismissible fade show"><?php echo $msg; ?> <button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>
    <?php endif; ?>

    <div class="tab-section <?php echo $current_tab=='dashboard'?'active-section':''; ?>">
        <div class="row g-3 mb-4">
            <div class="col-md-3"><div class="stat-card"><div><h3><?php echo $source_count; ?></h3><p class="text-muted small">接口数量</p></div><i class="bi bi-hdd-network fs-1 text-primary opacity-25"></i></div></div>
            <div class="col-md-3"><div class="stat-card"><div><h3><?php echo $user_count; ?></h3><p class="text-muted small">用户总数</p></div><i class="bi bi-people fs-1 text-success opacity-25"></i></div></div>
            <div class="col-md-3"><div class="stat-card"><div><h3><?php echo $card_count; ?></h3><p class="text-muted small">剩余卡密</p></div><i class="bi bi-credit-card fs-1 text-warning opacity-25"></i></div></div>
        </div>
        
        <div class="card p-4">
            <h5>💻 排版设置</h5>
            <form method="post">
                <input type="hidden" name="save_settings" value="1">
                <div class="row g-3 mt-2">
                    <div class="col-md-6">
                        <label>PC端列数</label>
                        <select name="home_layout_pc" class="form-select">
                            <option value="4" <?php echo $pc_val==4?'selected':''; ?>>4列</option>
                            <option value="6" <?php echo $pc_val==6?'selected':''; ?>>6列</option>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label>手机端列数</label>
                        <select name="home_layout_mb" class="form-select">
                            <option value="2" <?php echo $mb_val==2?'selected':''; ?>>2列</option>
                            <option value="1" <?php echo $mb_val==1?'selected':''; ?>>1列</option>
                        </select>
                    </div>
                </div>
                <button class="btn btn-primary mt-3">保存</button>
            </form>
        </div>
    </div>

    <div class="tab-section <?php echo $current_tab=='sources'?'active-section':''; ?>">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h4>📡 采集接口</h4>
            <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#addSourceModal">添加</button>
        </div>
        <div class="card">
            <table class="table table-hover mb-0 align-middle">
                <thead class="bg-light"><tr><th class="ps-4">名称</th><th>类型</th><th>地址</th><th class="text-end pe-4">操作</th></tr></thead>
                <tbody>
                    <?php if ($source_list && $source_list->num_rows > 0): $source_list->data_seek(0); while($row = $source_list->fetch_assoc()): ?>
                    <tr>
                        <td class="ps-4 fw-bold"><?php echo $row['name']; ?></td>
                        <td><?php echo ($row['type']=='video')?'<span class="badge bg-primary">短剧</span>':'<span class="badge bg-info">小说</span>'; ?></td>
                        <td class="text-muted small text-truncate" style="max-width: 300px;"><?php echo $row['api_url']; ?></td>
                        <td class="text-end pe-4"><a href="?tab=sources&delete_source=<?php echo $row['id']; ?>" class="btn btn-outline-danger btn-sm" onclick="return confirm('删除？')">删除</a></td>
                    </tr>
                    <?php endwhile; else: ?><tr><td colspan="4" class="text-center py-4 text-muted">暂无数据</td></tr><?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="tab-section <?php echo $current_tab=='cards'?'active-section':''; ?>">
        <div class="card p-4 mb-4">
            <h5 class="mb-3">🛠️ 生成 VIP 卡密</h5>
            <form method="post" class="row g-3">
                <input type="hidden" name="gen_cards" value="1">
                <input type="hidden" name="type" value="1"> 
                <div class="col-md-4"><input type="number" name="value" class="form-control" placeholder="天数 (例如 30)" required></div>
                <div class="col-md-4"><input type="number" name="num" class="form-control" value="10" required></div>
                <div class="col-md-4"><button class="btn btn-success w-100">生成</button></div>
            </form>
        </div>

        <div class="card">
            <div class="card-header d-flex justify-content-between bg-white align-items-center">
                <span>卡密列表</span>
                <a href="?tab=cards&clear_used=1" class="btn btn-sm btn-outline-danger" onclick="return confirm('清空已用？')">清理</a>
            </div>
            <table class="table table-hover mb-0 align-middle">
                <thead class="bg-light"><tr><th class="ps-4">卡号</th><th>面值</th><th>状态</th><th>操作</th></tr></thead>
                <tbody>
                    <?php 
                    // 修复点：使用 card_table_exists 变量判断
                    if ($card_table_exists) {
                        $cards = $conn->query("SELECT * FROM card_keys ORDER BY id DESC LIMIT 50");
                        if ($cards && $cards->num_rows > 0) {
                            while($row = $cards->fetch_assoc()): 
                    ?>
                    <tr>
                        <td class="ps-4 font-monospace text-primary"><?php echo $row['code']; ?></td>
                        <td class="fw-bold"><?php echo $row['value']; ?> 天VIP</td>
                        <td><?php echo ($row['status']==1)?'<span class="text-muted">已用</span>':'<span class="text-success">未使用</span>'; ?></td>
                        <td>
                            <?php if($row['status']==0): ?>
                                <button class="btn btn-sm btn-light border copy-btn" data-code="<?php echo $row['code']; ?>">复制</button>
                                <a href="?tab=cards&del_card=<?php echo $row['id']; ?>" class="btn btn-sm btn-link text-danger">删除</a>
                            <?php else: ?>
                                <small class="text-muted">UID:<?php echo $row['use_uid']; ?></small>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endwhile; 
                        } else { echo '<tr><td colspan="4" class="text-center py-4 text-muted">暂无卡密</td></tr>'; }
                    } else { echo '<tr><td colspan="4" class="text-center py-4 text-danger">卡密表不存在</td></tr>'; } 
                    ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="tab-section <?php echo $current_tab=='users'?'active-section':''; ?>">
        <div class="card">
            <div class="card-header bg-white">最新用户</div>
            <table class="table table-hover mb-0">
                <thead><tr><th>ID</th><th>账号</th><th>VIP状态</th></tr></thead>
                <tbody>
                    <?php 
                    if ($user_count > 0):
                        $users = $conn->query("SELECT * FROM users ORDER BY id DESC LIMIT 20");
                        while($u = $users->fetch_assoc()): 
                            $vip = ($u['vip_expire'] > time()) ? '<span class="text-warning">VIP</span>' : '<span class="text-muted">普通</span>';
                    ?>
                    <tr>
                        <td><?php echo $u['id']; ?></td>
                        <td><?php echo $u['username']; ?></td>
                        <td><?php echo $vip; ?></td>
                    </tr>
                    <?php endwhile; endif; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>

<div class="modal fade" id="addSourceModal" tabindex="-1"><div class="modal-dialog"><div class="modal-content"><div class="modal-header"><h5 class="modal-title">添加源</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div><form method="post"><div class="modal-body"><input type="hidden" name="add_source" value="1"><div class="mb-3"><label>名称</label><input type="text" name="name" class="form-control" required></div><div class="mb-3"><label>类型</label><select name="type" class="form-select"><option value="video">短剧</option><option value="novel">小说</option></select></div><div class="mb-3"><label>API</label><input type="text" name="api_url" class="form-control" required></div></div><div class="modal-footer"><button class="btn btn-primary">确认</button></div></form></div></div></div>

<script>
    document.querySelectorAll('.copy-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            navigator.clipboard.writeText(this.dataset.code);
            this.innerText = '已复制';
            setTimeout(() => this.innerText = '复制', 1000);
        });
    });
</script>
<script src="https://cdn.staticfile.org/bootstrap/5.1.3/js/bootstrap.bundle.min.js"></script>
</body>
</html>