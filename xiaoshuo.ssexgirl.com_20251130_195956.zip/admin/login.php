<?php
// admin/login.php - 管理员登录页
require $_SERVER['DOCUMENT_ROOT'] . '/core/db.php';

// 如果已经登录，直接跳后台
if (isset($_SESSION['admin_id'])) {
    header("Location: index.php");
    exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $conn->real_escape_string($_POST['username']);
    $password = md5($_POST['password']); // 使用 MD5 加密对比

    $sql = "SELECT * FROM system_admin WHERE username = '$username' AND password = '$password'";
    $res = $conn->query($sql);

    if ($res->num_rows > 0) {
        $row = $res->fetch_assoc();
        $_SESSION['admin_id'] = $row['id'];
        $_SESSION['admin_name'] = $row['username'];
        
        // 更新最后登录时间
        $conn->query("UPDATE system_admin SET last_login = NOW() WHERE id = " . $row['id']);
        
        header("Location: index.php");
        exit;
    } else {
        $error = "账号或密码错误";
    }
}
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>管理员登录</title>
    <link href="https://cdn.staticfile.org/bootstrap/5.1.3/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.staticfile.org/bootstrap-icons/1.8.1/font/bootstrap-icons.min.css">
    <style>
        body { background: #f4f6f9; display: flex; align-items: center; justify-content: center; height: 100vh; font-family: "PingFang SC", sans-serif; }
        .login-card { width: 100%; max-width: 400px; background: #fff; padding: 40px; border-radius: 16px; box-shadow: 0 10px 40px rgba(0,0,0,0.05); }
        .brand { font-size: 24px; font-weight: bold; color: #0d6efd; text-align: center; margin-bottom: 30px; }
        .form-control { padding: 12px; border-radius: 8px; background: #f8f9fa; border: 1px solid #eee; }
        .form-control:focus { background: #fff; box-shadow: none; border-color: #0d6efd; }
        .btn-login { width: 100%; padding: 12px; border-radius: 8px; font-weight: bold; font-size: 16px; margin-top: 20px; }
    </style>
</head>
<body>

<div class="login-card">
    <div class="brand"><i class="bi bi-shield-lock-fill"></i> 聚合管理系统</div>
    
    <?php if($error): ?>
    <div class="alert alert-danger py-2 small"><?php echo $error; ?></div>
    <?php endif; ?>

    <form method="post">
        <div class="mb-3">
            <label class="form-label text-muted small">账号</label>
            <input type="text" name="username" class="form-control" placeholder="请输入管理员账号" required>
        </div>
        <div class="mb-3">
            <label class="form-label text-muted small">密码</label>
            <input type="password" name="password" class="form-control" placeholder="请输入密码" required>
        </div>
        <button type="submit" class="btn btn-primary btn-login">登 录</button>
    </form>
    
    <div class="text-center mt-4 text-muted small">
        &copy; 2025 Aggregate Admin System
    </div>
</div>

</body>
</html>