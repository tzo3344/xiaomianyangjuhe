<?php
// admin/settings.php - 系统设置
require $_SERVER['DOCUMENT_ROOT'] . '/core/db.php';

// === 保存设置 ===
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $pc_layout = intval($_POST['home_layout_pc']);
    $mb_layout = intval($_POST['home_layout_mb']);
    
    // 更新或插入配置
    $conn->query("REPLACE INTO system_config (config_key, config_value) VALUES ('home_layout_pc', '$pc_layout')");
    $conn->query("REPLACE INTO system_config (config_key, config_value) VALUES ('home_layout_mb', '$mb_layout')");
    
    echo "<script>alert('✅ 设置已保存！前台排版已更新。');location.href='settings.php';</script>";
}

// === 读取当前设置 ===
$config = [];
$res = $conn->query("SELECT * FROM system_config");
while ($row = $res->fetch_assoc()) {
    $config[$row['config_key']] = $row['config_value'];
}

// 默认值兜底
$pc_val = $config['home_layout_pc'] ?? 3;
$mb_val = $config['home_layout_mb'] ?? 1;
?>

<!DOCTYPE html>
<html>
<head>
    <title>系统排版设置</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card shadow">
                    <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">🎨 网站排版设置</h5>
                        <a href="index.php" class="btn btn-sm btn-light text-primary">返回后台首页</a>
                    </div>
                    <div class="card-body">
                        <form method="post">
                            
                            <h6 class="border-bottom pb-2 mb-3">💻 电脑端排版 (宽屏)</h6>
                            <div class="mb-4">
                                <label class="form-label">一行显示几个卡片？</label>
                                <div class="btn-group w-100" role="group">
                                    <input type="radio" class="btn-check" name="home_layout_pc" id="pc3" value="3" <?php echo ($pc_val==3)?'checked':''; ?>>
                                    <label class="btn btn-outline-primary" for="pc3">3列 (大图模式)</label>

                                    <input type="radio" class="btn-check" name="home_layout_pc" id="pc4" value="4" <?php echo ($pc_val==4)?'checked':''; ?>>
                                    <label class="btn btn-outline-primary" for="pc4">4列 (标准模式)</label>

                                    <input type="radio" class="btn-check" name="home_layout_pc" id="pc6" value="6" <?php echo ($pc_val==6)?'checked':''; ?>>
                                    <label class="btn btn-outline-primary" for="pc6">6列 (密集模式)</label>
                                </div>
                                <div class="form-text text-muted">当前截图效果是3列。如果觉得卡片太大，可以选4列或6列。</div>
                            </div>

                            <h6 class="border-bottom pb-2 mb-3">📱 手机端排版 (窄屏)</h6>
                            <div class="mb-4">
                                <label class="form-label">一行显示几个？</label>
                                <div class="btn-group w-100" role="group">
                                    <input type="radio" class="btn-check" name="home_layout_mb" id="mb1" value="1" <?php echo ($mb_val==1)?'checked':''; ?>>
                                    <label class="btn btn-outline-primary" for="mb1">1列 (大图单排)</label>

                                    <input type="radio" class="btn-check" name="home_layout_mb" id="mb2" value="2" <?php echo ($mb_val==2)?'checked':''; ?>>
                                    <label class="btn btn-outline-primary" for="mb2">2列 (小图双排)</label>
                                </div>
                            </div>

                            <button type="submit" class="btn btn-success w-100 py-2">💾 保存设置</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>