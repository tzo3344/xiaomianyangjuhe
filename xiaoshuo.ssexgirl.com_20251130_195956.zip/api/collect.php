<?php
// 文件位置：/api/collect.php
// 作用：去上游获取 JSON 数据 (小说或视频)
require_once __DIR__ . '/../core/db.php';

function fetch_source_data($source_id, $params = []) {
    global $conn;

    // 1. 从数据库查 API 地址
    $sql = "SELECT * FROM collect_sources WHERE id = " . intval($source_id);
    $result = $conn->query($sql);
    
    if ($result->num_rows == 0) {
        return ['code' => 0, 'msg' => '采集源不存在'];
    }

    $source = $result->fetch_assoc();
    $api_url = $source['api_url'];

    // 2. 拼接参数
    // 苹果CMS标准参数：ac=list (列表), ac=detail (详情)
    $query_string = http_build_query($params);
    
    // 判断 api_url 原本有没有 ?
    if (strpos($api_url, '?') !== false) {
        $final_url = $api_url . '&' . $query_string;
    } else {
        $final_url = $api_url . '?' . $query_string;
    }

    // 3. 请求数据
    $json = file_get_contents($final_url);
    if (!$json) return ['code' => 0, 'msg' => '上游接口无响应'];

    return json_decode($json, true);
}
?>