<?php
// api/user_action.php - 纯净VIP版 (无积分)
header('Content-Type: application/json; charset=utf-8');
error_reporting(0);
ini_set('display_errors', 0);
session_start();

$db_file = __DIR__ . '/../core/db.php';
if (file_exists($db_file)) { require_once $db_file; } else { die(json_encode(['code'=>0, 'msg'=>'系统错误：找不到数据库文件'])); }
if (!isset($conn)) { die(json_encode(['code'=>0, 'msg'=>'系统错误：数据库连接断开'])); }

$act = isset($_GET['act']) ? $_GET['act'] : '';

// 1. 发送验证码
if ($act == 'send_code') {
    $email = isset($_POST['email']) ? trim($_POST['email']) : '';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) die(json_encode(['code'=>0, 'msg'=>'邮箱格式不正确']));
    $code = rand(100000, 999999);
    $_SESSION['email_code'] = $code;
    $_SESSION['email_addr'] = $email;
    die(json_encode(['code'=>1, 'msg'=>'验证码已发送', 'debug_code'=>$code]));
}

// 2. 注册
elseif ($act == 'reg') {
    $user = trim($_POST['username']);
    $pass = trim($_POST['password']);
    $email = trim($_POST['email']);
    $vcode = trim($_POST['vcode']);
    $invite = trim($_POST['invite']); 
    
    if (strlen($user) < 3) die(json_encode(['code'=>0, 'msg'=>'账号太短']));
    if (strlen($pass) < 5) die(json_encode(['code'=>0, 'msg'=>'密码太短']));
    // 验证码校验
    if (empty($_SESSION['email_code']) || $vcode != $_SESSION['email_code']) die(json_encode(['code'=>0, 'msg'=>'验证码错误']));
    
    $check = $conn->query("SELECT id FROM users WHERE username = '$user'");
    if ($check->num_rows > 0) die(json_encode(['code'=>0, 'msg'=>'账号已存在']));
    
    $pass_md5 = md5($pass);
    $ip = $_SERVER['REMOTE_ADDR'];
    $time = time();
    // 移除 point 字段
    $sql = "INSERT INTO users (username, password, email, invite_code, reg_ip, reg_time, nickname) VALUES ('$user', '$pass_md5', '$email', '$invite', '$ip', $time, '$user')";
            
    if ($conn->query($sql)) {
        unset($_SESSION['email_code']);
        echo json_encode(['code'=>1, 'msg'=>'注册成功！']);
    } else {
        echo json_encode(['code'=>0, 'msg'=>'注册失败']);
    }
}

// 3. 登录
elseif ($act == 'login') {
    $user = trim($_POST['username']);
    $pass = trim($_POST['password']);
    $pass_md5 = md5($pass);
    $sql = "SELECT * FROM users WHERE (username='$user' OR email='$user') AND password='$pass_md5'";
    $res = $conn->query($sql);
    if ($res && $res->num_rows > 0) {
        $row = $res->fetch_assoc();
        $_SESSION['user_id'] = $row['id'];
        $_SESSION['user_name'] = $row['nickname'] ? $row['nickname'] : $row['username'];
        echo json_encode(['code'=>1, 'msg'=>'登录成功']);
    } else {
        echo json_encode(['code'=>0, 'msg'=>'账号或密码错误']);
    }
}

// 4. 卡密充值 (仅支持VIP天数)
elseif ($act == 'exchange') {
    if (!isset($_SESSION['user_id'])) die(json_encode(['code'=>0, 'msg'=>'请先登录']));
    $uid = $_SESSION['user_id'];
    $code = isset($_POST['code']) ? trim($_POST['code']) : '';
    
    $res = $conn->query("SELECT * FROM card_keys WHERE code='$code'");
    if ($res->num_rows == 0) die(json_encode(['code'=>0, 'msg'=>'卡密不存在']));
    $card = $res->fetch_assoc();
    if ($card['status'] == 1) die(json_encode(['code'=>0, 'msg'=>'卡密已使用']));
    
    // 标记已使用
    $conn->query("UPDATE card_keys SET status=1, use_time=".time().", use_uid=$uid WHERE id=".$card['id']);
    
    // 直接增加VIP时间 (不再判断type=2的情况)
    $user = $conn->query("SELECT vip_expire FROM users WHERE id=$uid")->fetch_assoc();
    $start = ($user['vip_expire'] > time()) ? $user['vip_expire'] : time();
    $new_expire = $start + ($card['value'] * 86400); // 天数转秒
    
    $conn->query("UPDATE users SET vip_expire=$new_expire WHERE id=$uid");
    echo json_encode(['code'=>1, 'msg'=>"充值成功！增加 {$card['value']} 天VIP"]);
}

// 5. 更新资料
elseif ($act == 'update_profile') {
    if (!isset($_SESSION['user_id'])) die(json_encode(['code'=>0, 'msg'=>'请先登录']));
    $uid = $_SESSION['user_id'];
    $nickname = $conn->real_escape_string($_POST['nickname']);
    
    $update_sql = "UPDATE users SET nickname='$nickname' WHERE id=$uid";
    
    if (isset($_FILES['avatar']) && $_FILES['avatar']['error'] == 0) {
        $allow = ['jpg', 'jpeg', 'png', 'gif'];
        $ext = pathinfo($_FILES['avatar']['name'], PATHINFO_EXTENSION);
        if (in_array(strtolower($ext), $allow)) {
            $dir = $_SERVER['DOCUMENT_ROOT'] . '/upload/avatar/';
            if (!is_dir($dir)) mkdir($dir, 0777, true);
            $filename = 'u_'.$uid.'_'.time().'.'.$ext;
            if (move_uploaded_file($_FILES['avatar']['tmp_name'], $dir.$filename)) {
                $avatar_url = '/upload/avatar/'.$filename;
                $update_sql = "UPDATE users SET nickname='$nickname', avatar='$avatar_url' WHERE id=$uid";
            }
        }
    }
    if ($conn->query($update_sql)) {
        $_SESSION['user_name'] = $nickname;
        echo json_encode(['code'=>1, 'msg'=>'资料已更新']);
    } else {
        echo json_encode(['code'=>0, 'msg'=>'更新失败']);
    }
}

// 6. 修改密码
elseif ($act == 'change_password') {
    if (!isset($_SESSION['user_id'])) die(json_encode(['code'=>0, 'msg'=>'请先登录']));
    $uid = $_SESSION['user_id'];
    $old_pwd = md5(trim($_POST['old_pwd']));
    $new_pwd = trim($_POST['new_pwd']);
    $confirm_pwd = trim($_POST['confirm_pwd']);
    
    if (strlen($new_pwd) < 5) die(json_encode(['code'=>0, 'msg'=>'新密码至少5位']));
    if ($new_pwd != $confirm_pwd) die(json_encode(['code'=>0, 'msg'=>'两次新密码不一致']));
    
    $check = $conn->query("SELECT id FROM users WHERE id=$uid AND password='$old_pwd'");
    if ($check->num_rows == 0) die(json_encode(['code'=>0, 'msg'=>'原密码错误']));
    
    $new_pwd_md5 = md5($new_pwd);
    if ($conn->query("UPDATE users SET password='$new_pwd_md5' WHERE id=$uid")) {
        session_destroy(); 
        echo json_encode(['code'=>1, 'msg'=>'修改成功，请重新登录']);
    } else {
        echo json_encode(['code'=>0, 'msg'=>'修改失败']);
    }
}

elseif ($act == 'logout') {
    session_destroy();
    header("Location: /login.php");
}
?>