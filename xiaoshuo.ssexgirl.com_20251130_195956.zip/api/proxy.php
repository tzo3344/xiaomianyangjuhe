<?php
// 文件位置：/api/proxy.php
// 作用：V2 强力版 - 增加缓冲区清理，防止视频流损坏
error_reporting(0); // 屏蔽所有报错

// 核心：清除缓冲区，防止之前的 PHP 文件输出了空格或警告，导致视频损坏
if (ob_get_level()) ob_end_clean();

// 1. 获取参数
$url = isset($_GET['url']) ? $_GET['url'] : '';
if (empty($url)) die('Error: Missing URL');

// 解码 (防止多重编码问题)
$url = urldecode($url);

// 2. 你的域名地址 (自动识别 http 或 https)
$protocol = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') ? "https://" : "http://";
$my_domain = $protocol . $_SERVER['HTTP_HOST'] . '/api/proxy.php?url=';

// 3. 伪装请求头 (模拟浏览器)
$headers = [
    "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36",
    // 如果源需要 Referer，通常设置为源的域名，或者留空
    "Referer: " . dirname($url)
];

// 4. 初始化 CURL
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0); 
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_TIMEOUT, 60); 
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);

$data = curl_exec($ch);
$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$content_type = curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
$error = curl_error($ch);
curl_close($ch);

// 如果抓取失败
if ($http_code != 200 || !$data) {
    header("HTTP/1.1 404 Not Found");
    die("Proxy Error: $error | Code: $http_code");
}

// 5. 判断内容类型
// 情况 A: 这是一个 m3u8 索引文件
if (strpos($data, '#EXTM3U') !== false) {
    header('Content-Type: application/vnd.apple.mpegurl');
    header('Access-Control-Allow-Origin: *'); 

    // 获取上游 m3u8 的基础路径
    $base_url = dirname($url) . '/';

    // 逐行处理替换
    $lines = explode("\n", $data);
    foreach ($lines as $line) {
        $line = trim($line);
        if (empty($line)) continue;

        // 注释行直接输出
        if (substr($line, 0, 1) == '#') {
            echo $line . "\n";
        } else {
            // 这是视频片段 (.ts) 或 嵌套的 m3u8
            // 处理相对路径
            if (substr($line, 0, 4) != 'http') {
                // 如果是以 / 开头的绝对路径 (如 /2023/video.ts)
                if (substr($line, 0, 1) == '/') {
                    $domain_part = parse_url($url, PHP_URL_SCHEME) . '://' . parse_url($url, PHP_URL_HOST);
                    $real_ts_url = $domain_part . $line;
                } else {
                    $real_ts_url = $base_url . $line;
                }
            } else {
                $real_ts_url = $line;
            }

            // 再次包裹
            echo $my_domain . urlencode($real_ts_url) . "\n";
        }
    }
} 
// 情况 B: 这是视频流 (.ts)
else {
    header('Content-Type: video/mp2t');
    header('Access-Control-Allow-Origin: *');
    header('Cache-Control: public, max-age=86400');
    // 直接输出二进制视频数据
    echo $data;
}
exit;
?>