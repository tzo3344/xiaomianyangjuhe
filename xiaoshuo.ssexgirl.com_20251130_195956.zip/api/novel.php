<?php
// api/novel.php - 小说聚合接口 (复刻方案2)
header('Content-Type: application/json; charset=utf-8');
// 允许跨域
header("Access-Control-Allow-Origin: *");
error_reporting(0);

// === ⚙️ 配置区 ===
// 你的 B 服务器 Reader 地址 (必须带端口)
$reader_host = "http://213.111.156.74:8081"; 
// 缓存开关 (建议开启，提速明显)
$use_cache = true;
$cache_dir = $_SERVER['DOCUMENT_ROOT'] . '/cache/novel_api/';
if ($use_cache && !is_dir($cache_dir)) @mkdir($cache_dir, 0777, true);
// =================

// 获取参数
$ac = isset($_GET['ac']) ? $_GET['ac'] : 'list'; // list=搜索, detail=详情, content=内容
$wd = isset($_GET['wd']) ? trim($_GET['wd']) : '';
$ids = isset($_GET['ids']) ? trim($_GET['ids']) : '';
$url = isset($_GET['url']) ? trim($_GET['url']) : '';

// === 内部函数：请求 B 服务器 ===
function request_reader($path, $params = []) {
    global $reader_host;
    $url = $reader_host . $path;
    if (!empty($params)) $url .= '?' . http_build_query($params);
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_TIMEOUT, 20); // 爬虫给20秒
    // 伪装 UserAgent
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36');
    $res = curl_exec($ch);
    curl_close($ch);
    return json_decode($res, true);
}

// === 内部函数：缓存读写 ===
function cache_get($key) {
    global $use_cache, $cache_dir;
    if (!$use_cache) return false;
    $file = $cache_dir . md5($key) . '.json';
    if (file_exists($file) && (time() - filemtime($file) < 3600)) { // 默认缓存1小时
        return json_decode(file_get_contents($file), true);
    }
    return false;
}
function cache_set($key, $data) {
    global $use_cache, $cache_dir;
    if ($use_cache) file_put_contents($cache_dir . md5($key) . '.json', json_encode($data));
}

// ==========================
// 🚀 接口逻辑实现
// ==========================

// 1. 搜索接口 (ac=list)
if ($ac == 'list') {
    if (empty($wd)) die(json_encode(['code'=>1, 'list'=>[], 'total'=>0]));
    
    // 尝试读缓存 (搜索结果缓存10分钟即可，这里复用通用缓存逻辑)
    $cache_key = 'search_' . $wd;
    $cached = cache_get($cache_key);
    if ($cached) { echo json_encode($cached); exit; }

    // 请求 Reader 搜索
    $res = request_reader('/reader3/search', ['key' => $wd]);
    
    $list = [];
    if (isset($res['data']) && is_array($res['data'])) {
        foreach ($res['data'] as $book) {
            // 构造 ID：把书本URL和源URL加密，作为唯一标识
            $real_id = base64_encode($book['bookUrl'] . '|||' . $book['sourceUrl']);
            
            // 格式化为 Maccms 标准字段
            $list[] = [
                'vod_id' => 'NOVEL_' . $real_id, // 加前缀区分
                'vod_name' => $book['name'],
                'vod_pic' => $book['coverUrl'],
                'vod_actor' => $book['author'],
                'vod_remarks' => $book['kind'] ?: '小说',
                'vod_content' => $book['intro'],
                'type_name' => '小说'
            ];
        }
    }
    
    $output = ['code'=>1, 'list'=>$list, 'total'=>count($list), 'page'=>1, 'pagecount'=>1];
    cache_set($cache_key, $output);
    echo json_encode($output);
}

// 2. 详情接口 (ac=detail)
elseif ($ac == 'detail') {
    // 如果传过来的是 ids (兼容采集器逻辑)
    $target_id = $ids ?: $_GET['id'];
    if (empty($target_id)) die(json_encode(['code'=>0, 'msg'=>'No ID']));

    // 读缓存
    $cache_key = 'detail_' . $target_id;
    $cached = cache_get($cache_key);
    if ($cached) { echo json_encode($cached); exit; }

    // 解密 ID
    $raw_id = str_replace('NOVEL_', '', $target_id);
    $decoded = base64_decode($raw_id);
    if (!$decoded) die(json_encode(['code'=>0, 'msg'=>'ID错误']));
    
    list($bookUrl, $sourceUrl) = explode('|||', $decoded);

    // 请求 Reader 获取目录 (TOC)
    $res = request_reader('/reader3/book/toc', ['url' => $bookUrl, 'sourceUrl' => $sourceUrl]);
    
    if (isset($res['data'])) {
        $book = $res['data'];
        $chapters = $book['toc'] ?? $res['data']; // 兼容不同版本
        
        $playlist = [];
        if (is_array($chapters)) {
            foreach ($chapters as $chap) {
                // 章节ID加密：章节URL ||| 源URL ||| 书本URL
                // 格式：章节名$URL
                $chap_id = base64_encode($chap['url'] . '|||' . $sourceUrl . '|||' . $bookUrl);
                // 构造播放地址：read.php?url=xxxx
                // 这里我们直接把参数拼好，方便前端直接用
                $playlist[] = $chap['name'] . '$' . $chap_id; 
            }
        }

        $info = [
            'vod_id' => $target_id,
            'vod_name' => $book['name'],
            'vod_pic' => $book['coverUrl'],
            'vod_actor' => $book['author'],
            'vod_content' => $book['intro'],
            'type_name' => '小说',
            'vod_remarks' => '共'.count($playlist).'章',
            'vod_play_url' => implode('#', $playlist)
        ];
        
        $output = ['code'=>1, 'list'=>[$info]];
        cache_set($cache_key, $output);
        echo json_encode($output);
    } else {
        echo json_encode(['code'=>0, 'msg'=>'源站请求失败']);
    }
}

// 3. 正文接口 (ac=content) -> 供 read_spider.php 调用
elseif ($ac == 'content') {
    if (empty($url)) die(json_encode(['code'=>0, 'msg'=>'No URL']));
    
    // 永久缓存正文 (书的内容一般不会变)
    $cache_key = 'content_' . md5($url);
    $cached = cache_get($cache_key);
    if ($cached) { echo json_encode($cached); exit; }

    $decoded = base64_decode($url);
    $params = explode('|||', $decoded);
    
    $res = request_reader('/reader3/book/content', [
        'url' => $params[0],
        'sourceUrl' => $params[1],
        'bookUrl' => $params[2]
    ]);
    
    if (isset($res['data'])) {
        // 简单排版：换行符转段落
        $text = $res['data'];
        $text = str_replace("\n", "</p><p>", $text);
        $text = "<p>" . $text . "</p>";
        
        $output = ['code'=>1, 'content'=>$text];
        // 写入缓存
        file_put_contents($cache_dir . md5($cache_key) . '.json', json_encode($output));
        echo json_encode($output);
    } else {
        echo json_encode(['code'=>0, 'msg'=>'内容获取失败']);
    }
}
?>