<?php
// 文件位置：/core/db.php
// 作用：连接数据库，所有页面都要引用它

// 设置时区和编码
header("Content-type: text/html; charset=utf-8");
date_default_timezone_set('Asia/Shanghai');

// 数据库配置 (请把下面的 'root', '密码', '数据库名' 改成你自己的)
$db_host = '127.0.0.1';
$db_user = 'root';        // <--- 这里填你的数据库用户名
$db_pass = 'Tzo10192001'; // <--- 这里填你的数据库密码
$db_name = 'xiaoshuo';   // <--- 这里填你的数据库名称

// 创建连接
$conn = new mysqli($db_host, $db_user, $db_pass, $db_name);

// 检查连接
if ($conn->connect_error) {
    die("数据库连接失败，请检查 core/db.php 文件: " . $conn->connect_error);
}

$conn->set_charset("utf8mb4"); // 防止中文乱码
session_start(); // 开启会员登录状态保持
?>