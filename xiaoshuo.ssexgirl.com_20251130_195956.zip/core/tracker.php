<?php
// core/tracker.php - 行为记录器
if (session_status() == PHP_SESSION_NONE) session_start();

function record_history($vod_id, $vod_name) {
    global $conn;
    // 没登录不记录
    if (!isset($_SESSION['user_id'])) return;
    
    $uid = $_SESSION['user_id'];
    $ip = $_SERVER['REMOTE_ADDR'];
    $ua = $_SERVER['HTTP_USER_AGENT']; // 获取设备信息
    $time = time();
    
    // 简单防刷：同一资源，1分钟内不重复记录
    // (这里为了性能，先不查重，直接插入，统计时再去重)
    $sql = "INSERT INTO user_history (user_id, vod_id, vod_name, log_time, ip, device) VALUES ('$uid', '$vod_id', '$vod_name', '$time', '$ip', '$ua')";
    $conn->query($sql);
}
?>