<?php
require $_SERVER['DOCUMENT_ROOT'] . '/core/db.php';
if (!isset($_SESSION['user_id'])) { header("Location: /login.php"); exit; }

$uid = $_SESSION['user_id'];
$user = $conn->query("SELECT * FROM users WHERE id=$uid")->fetch_assoc();

// 数据处理
$is_vip = ($user['vip_expire'] > time());
$vip_date = $is_vip ? date('Y-m-d', $user['vip_expire']) : '未开通';
$reg_date = date('Y-m-d', $user['reg_time']);
$avatar = $user['avatar'] ?: '/static/default_avatar.png';
if(!file_exists($_SERVER['DOCUMENT_ROOT'].$avatar)) $avatar = 'https://ui-avatars.com/api/?background=random&name='.$user['username'];

// 获取数据统计
$today_start = strtotime(date('Y-m-d 00:00:00'));
$read_today = $conn->query("SELECT count(*) as c FROM user_history WHERE user_id=$uid AND log_time >= $today_start")->fetch_assoc()['c'];
$read_total = $conn->query("SELECT count(*) as c FROM user_history WHERE user_id=$uid")->fetch_assoc()['c'];
$device_list = $conn->query("SELECT * FROM user_history WHERE user_id=$uid GROUP BY ip ORDER BY log_time DESC LIMIT 5");
$device_count = $device_list->num_rows;
$status_text = ($user['status'] == 1) ? '正常' : '异常';
$status_color = ($user['status'] == 1) ? 'text-success' : 'text-danger';
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>用户中心</title>
    <link href="https://cdn.staticfile.org/bootstrap/5.1.3/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.staticfile.org/bootstrap-icons/1.8.1/font/bootstrap-icons.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            font-family: "PingFang SC", sans-serif; min-height: 100vh;
            display: flex; justify-content: center; padding: 20px;
        }
        .main-container {
            width: 100%; max-width: 1000px; background: #fff; border-radius: 12px;
            box-shadow: 0 20px 50px rgba(0,0,0,0.2); overflow: hidden; min-height: 850px;
            display: flex; flex-direction: column;
        }
        .top-header { background: #6f55b0; color: #fff; padding: 15px 30px; display: flex; justify-content: space-between; align-items: center; }
        .top-avatar { width: 32px; height: 32px; border-radius: 50%; object-fit: cover; border: 2px solid rgba(255,255,255,0.3); }
        .nav-tabs { padding: 0 20px; border-bottom: 1px solid #eee; background: #fff; }
        .nav-link { color: #666; border: none !important; padding: 15px 25px; font-weight: 500; cursor: pointer; }
        .nav-link.active { color: #6f55b0; border-bottom: 3px solid #6f55b0 !important; font-weight: bold; }
        .content-area { padding: 30px; background: #f9fbfd; flex: 1; }
        
        .user-card { background: #fff; border-radius: 12px; padding: 40px; text-align: center; border: 1px solid #eee; margin-bottom: 25px; }
        .big-avatar { width: 80px; height: 80px; margin: 0 auto 15px; background: linear-gradient(135deg, #667eea, #764ba2); border-radius: 50%; color: #fff; font-size: 40px; display: flex; align-items: center; justify-content: center; overflow: hidden; }
        .shortcut-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 15px; margin-bottom: 25px; }
        .shortcut-item { background: #fff; border: 1px solid #eee; border-radius: 10px; padding: 20px; text-align: center; cursor: pointer; text-decoration: none; color: inherit; transition:0.2s;}
        .shortcut-item:hover { transform: translateY(-3px); border-color: #6f55b0; }
        .data-list { background: #fff; border-radius: 12px; border: 1px solid #eee; overflow: hidden; }
        .data-row { display: flex; justify-content: space-between; align-items: center; padding: 15px 20px; border-bottom: 1px solid #f5f5f5; font-size: 14px; }
        .data-label { color: #666; display: flex; align-items: center; gap: 10px; }
        .data-value { color: #333; font-weight: 500; }

        /* 管理页样式 */
        .setting-card { background: #fff; border: 1px solid #eee; border-radius: 12px; padding: 25px; margin-bottom: 20px; }
        .setting-title { font-weight: bold; color: #333; margin-bottom: 20px; display: flex; align-items: center; gap: 8px; font-size: 16px; }
        
        .btn-purple { background: #5b6de3; color: #fff; border: none; width: 100%; padding: 10px; border-radius: 8px; font-weight: bold; transition: 0.2s; }
        .btn-purple:hover { background: #4a5cc7; color: #fff; }
        .btn-red { background: #dc3545; color: #fff; border: none; width: 100%; padding: 10px; border-radius: 8px; font-weight: bold; transition: 0.2s; }
        .btn-red:hover { background: #bb2d3b; color: #fff; }
        .btn-upload { background: #5b6de3; color: #fff; border: none; padding: 8px 20px; border-radius: 6px; font-size: 13px; cursor: pointer; display: block; width: 100%; text-align: center; }
        
        .device-item { background: #eef2ff; padding: 15px; border-radius: 8px; display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px; border: 1px solid #e0e7ff; }
        .device-tag { background: #fb923c; color: white; padding: 2px 8px; border-radius: 4px; font-size: 12px; margin-left: 10px; }
        
        .form-control { background: #fff; border: 1px solid #eee; border-radius: 8px; padding: 10px 15px; font-size: 14px; }
        .form-control:focus { border-color: #5b6de3; box-shadow: 0 0 0 3px rgba(91, 109, 227, 0.1); }
        
        .contact-btn {
            display: flex; align-items: center; justify-content: center; width: 100%;
            padding: 12px; border-radius: 8px; font-weight: bold; color: #fff; text-decoration: none;
            transition: transform 0.2s;
        }
        .contact-btn:hover { transform: translateY(-2px); color: #fff; }
        .bg-tg { background: #7c72e6; }
        .bg-doc { background: #6f55b0; }
        
        .alert-soft-red { background: #fff5f5; color: #c53030; border: 1px dashed #fc8181; font-size: 12px; padding: 10px; border-radius: 8px; margin-top: 15px; }
        
        @media (max-width: 768px) {
            body { padding: 0; background: #f9fbfd; }
            .main-container { border-radius: 0; min-height: 100vh; }
            .shortcut-grid { grid-template-columns: repeat(2, 1fr); }
        }
    </style>
</head>
<body>

<div class="main-container">
    <div class="top-header">
        <div class="d-flex align-items-center gap-2">
            <img src="<?php echo $avatar; ?>" class="top-avatar">
            <div>
                <div style="font-size:14px; font-weight:bold;"><?php echo $user['nickname'] ?: $user['username']; ?></div>
                <div style="font-size:12px; opacity:0.8;">用户中心</div>
            </div>
        </div>
        <a href="/api/user_action.php?act=logout" class="btn btn-sm bg-white text-dark border-0 rounded-pill px-3 fw-bold" style="box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
            <i class="bi bi-box-arrow-right"></i> 退出
        </a>
    </div>

    <ul class="nav nav-tabs">
        <li class="nav-item"><a class="nav-link active" onclick="switchTab('overview', this)"><i class="bi bi-person"></i> 概览</a></li>
        <li class="nav-item"><a class="nav-link" onclick="switchTab('manage', this)"><i class="bi bi-gear"></i> 管理</a></li>
        <li class="nav-item"><a class="nav-link" onclick="tip()"><i class="bi bi-shield-check"></i> 监控</a></li>
    </ul>

    <div class="content-area">
        
        <div id="view-overview">
            <div class="user-card">
                <div class="big-avatar">
                    <img src="<?php echo $avatar; ?>" style="width:100%;height:100%;object-fit:cover;">
                </div>
                <div class="fs-5 fw-bold mb-1"><?php echo $user['email'] ?: $user['username']; ?></div>
                <span class="badge rounded-pill <?php echo $is_vip?'bg-warning text-dark':'bg-secondary'; ?>">
                    <?php echo $is_vip ? '尊贵VIP' : '普通用户'; ?>
                </span>
                </div>

            <div class="shortcut-grid">
                <a href="/" class="shortcut-item">
                    <i class="bi bi-book-half fs-3 text-primary d-block mb-2"></i>
                    <div class="fw-bold small">开始阅读</div>
                </a>
                <a href="javascript:;" class="shortcut-item" onclick="openExchange()">
                    <i class="bi bi-gem fs-3 text-warning d-block mb-2"></i>
                    <div class="fw-bold small">卡密充值</div>
                </a>
                <a href="javascript:;" class="shortcut-item" onclick="tip()">
                    <i class="bi bi-bookmark-heart fs-3 text-danger d-block mb-2"></i>
                    <div class="fw-bold small">我的收藏</div>
                </a>
                <a href="javascript:;" class="shortcut-item" onclick="tip()">
                    <i class="bi bi-headset fs-3 text-info d-block mb-2"></i>
                    <div class="fw-bold small">联系客服</div>
                </a>
            </div>

            <div class="data-list">
                <div class="data-row">
                    <span class="data-label"><i class="bi bi-key"></i> 用户 UID</span>
                    <span class="data-value font-monospace"><?php echo 10000 + $uid; ?></span>
                </div>
                <div class="data-row">
                    <span class="data-label"><i class="bi bi-clock-history"></i> VIP 到期</span>
                    <span class="data-value <?php echo $is_vip?'text-warning':'text-muted'; ?>"><?php echo $vip_date; ?></span>
                </div>
                <div class="data-row">
                    <span class="data-label"><i class="bi bi-calendar-check"></i> 注册时间</span>
                    <span class="data-value"><?php echo $reg_date; ?></span>
                </div>
                <div class="data-row">
                    <span class="data-label"><i class="bi bi-journal-text"></i> 今日阅读</span>
                    <span class="data-value"><?php echo $read_today; ?> 次</span>
                </div>
                <div class="data-row">
                    <span class="data-label"><i class="bi bi-graph-up-arrow"></i> 累计阅读</span>
                    <span class="data-value"><?php echo $read_total; ?> 次</span>
                </div>
                <div class="data-row">
                    <span class="data-label"><i class="bi bi-phone"></i> 关联设备IP</span>
                    <span class="data-value"><?php echo $device_count; ?> 个</span>
                </div>
                <div class="data-row">
                    <span class="data-label"><i class="bi bi-shield-check"></i> 账号状态</span>
                    <span class="data-value <?php echo $status_color; ?>"><?php echo $status_text; ?></span>
                </div>
            </div>
        </div>

        <div id="view-manage" style="display:none;">
            
            <div class="setting-card">
                <div class="setting-title"><i class="bi bi-image text-primary"></i> 头像与昵称设置</div>
                <form id="profileForm">
                    <div class="d-flex gap-3 align-items-center mb-3 p-3 bg-light rounded">
                        <img src="<?php echo $avatar; ?>" style="width:60px;height:60px;border-radius:50%;object-fit:cover;" id="preview-avatar">
                        <div style="flex:1">
                            <label class="btn-upload mb-2">
                                <i class="bi bi-camera"></i> 更换头像
                                <input type="file" name="avatar" hidden onchange="previewImage(this)">
                            </label>
                            <div class="text-muted small">支持JPG/PNG，最大5MB</div>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small text-muted">昵称</label>
                        <input type="text" name="nickname" class="form-control" value="<?php echo $user['nickname']; ?>" placeholder="请输入新昵称">
                    </div>
                    <button type="submit" class="btn-purple"><i class="bi bi-save"></i> 保存更改</button>
                </form>
            </div>

            <div class="setting-card">
                <div class="setting-title"><i class="bi bi-phone text-primary"></i> 设备管理</div>
                <p class="text-muted small mb-3">已关联设备: <?php echo $device_list->num_rows; ?> 个</p>
                <?php 
                if ($device_list->num_rows > 0) {
                    $device_list->data_seek(0);
                    while($dev = $device_list->fetch_assoc()): 
                ?>
                <div class="device-item">
                    <div>
                        <i class="bi bi-phone"></i> 
                        IP: <?php echo $dev['ip']; ?>
                        <?php if($dev['ip'] == $_SERVER['REMOTE_ADDR']) echo '<span class="device-tag">本机</span>'; ?>
                    </div>
                    <button class="btn btn-sm btn-light text-danger border" onclick="tip('功能开发中')"><i class="bi bi-trash"></i></button>
                </div>
                <?php endwhile; } else { echo '<div class="text-center text-muted small p-3">暂无记录</div>'; } ?>
                <button class="btn-red mt-2" onclick="tip('功能开发中')"><i class="bi bi-trash"></i> 清除所有设备</button>
            </div>

            <div class="setting-card">
                <div class="setting-title"><i class="bi bi-key text-primary"></i> 修改密码</div>
                <form id="pwdForm">
                    <div class="mb-3"><label class="form-label small text-muted">原始密码</label><input type="password" name="old_pwd" class="form-control" required></div>
                    <div class="mb-3"><label class="form-label small text-muted">新密码</label><input type="password" name="new_pwd" class="form-control" required></div>
                    <div class="mb-3"><label class="form-label small text-muted">确认密码</label><input type="password" name="confirm_pwd" class="form-control" required></div>
                    <button type="submit" class="btn-purple"><i class="bi bi-check-lg"></i> 提交修改</button>
                </form>
            </div>

            <div class="setting-card">
                <div class="setting-title"><i class="bi bi-envelope text-primary"></i> 联系我们</div>
                <div class="row g-3">
                    <div class="col-6"><a href="#" class="contact-btn bg-tg"><i class="bi bi-telegram me-2"></i> 电报群</a></div>
                    <div class="col-6"><a href="#" class="contact-btn bg-doc"><i class="bi bi-book me-2"></i> 教程</a></div>
                </div>
            </div>
        </div>

    </div>
</div>

<script>
function switchTab(tabName, btn) {
    document.getElementById('view-overview').style.display = 'none';
    document.getElementById('view-manage').style.display = 'none';
    document.querySelectorAll('.nav-link').forEach(el => el.classList.remove('active'));
    document.getElementById('view-' + tabName).style.display = 'block';
    btn.classList.add('active');
}
function previewImage(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();
        reader.onload = function (e) { document.getElementById('preview-avatar').src = e.target.result; }
        reader.readAsDataURL(input.files[0]);
    }
}
document.getElementById('profileForm').addEventListener('submit', function(e) {
    e.preventDefault();
    let formData = new FormData(this);
    fetch('/api/user_action.php?act=update_profile', { method: 'POST', body: formData }).then(r=>r.json()).then(d=>{
        Swal.fire({icon:d.code===1?'success':'error',title:d.msg,timer:1500,showConfirmButton:false}).then(()=>{if(d.code===1)location.reload()});
    });
});
document.getElementById('pwdForm').addEventListener('submit', function(e) {
    e.preventDefault();
    let formData = new FormData(this);
    fetch('/api/user_action.php?act=change_password', { method: 'POST', body: formData }).then(r=>r.json()).then(d=>{
        if(d.code===1) Swal.fire({icon:'success',title:'修改成功'}).then(()=>location.href='/login.php');
        else Swal.fire({icon:'error',title:d.msg});
    });
});
function tip(msg='功能开发中') { Swal.fire('提示', msg, 'info'); }
async function openExchange() {
    const { value: code } = await Swal.fire({
        title: '卡密充值', input: 'text', inputPlaceholder: '请输入VIP卡密',
        showCancelButton: true, confirmButtonText: '兑换', confirmButtonColor: '#6f55b0'
    });
    if (code) {
        let fd = new FormData(); fd.append('code', code);
        fetch('/api/user_action.php?act=exchange', { method:'POST', body:fd })
            .then(r=>r.json()).then(d => Swal.fire(d.code===1?'成功':'失败', d.msg, d.code===1?'success':'error').then(()=>{if(d.code===1)location.reload()}));
    }
}
</script>

</body>
</html>