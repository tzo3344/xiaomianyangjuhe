<?php
// final_debug.php - 暴力破解搜索接口
header("Content-type: text/html; charset=utf-8");
ini_set('display_errors', 1);
error_reporting(E_ALL);

$host = "http://213.111.156.74:8081";
$keyword = "剑来";

// 常见的搜索路径
$paths = [
    "/reader3/search?key=" . urlencode($keyword),       // 路径1
    "/reader3/book/search?key=" . urlencode($keyword),  // 路径2
    "/reader3/searchBook?key=" . urlencode($keyword),   // 路径3
];

echo "<h2>🔍 搜索接口暴力探测</h2>";

foreach ($paths as $path) {
    $url = $host . $path;
    echo "<hr><strong>测试目标：</strong> $url <br>";

    // === 测试 1: GET 请求 ===
    echo "📡 尝试 GET 请求... ";
    $res_get = curl_request($url, 'GET');
    check_result($res_get, 'GET');

    // === 测试 2: POST 请求 ===
    echo "📡 尝试 POST 请求... ";
    $res_post = curl_request($url, 'POST');
    check_result($res_post, 'POST');
}

function curl_request($url, $method) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    if ($method == 'POST') {
        curl_setopt($ch, CURLOPT_POST, 1);
        // 有些版本需要空的 body 才能触发搜索
        curl_setopt($ch, CURLOPT_POSTFIELDS, "{}"); 
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    }
    $res = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return ['code' => $code, 'body' => $res];
}

function check_result($res, $method) {
    if ($res['code'] == 200) {
        $json = json_decode($res['body'], true);
        // 检查是否有数据
        $count = 0;
        if (isset($json['data'])) $count = count($json['data']);
        elseif (isset($json['list'])) $count = count($json['list']);
        elseif (is_array($json)) $count = count($json);

        if ($count > 0) {
            echo "<span style='color:green;font-weight:bold'>✅ 成功！(HTTP 200) - 搜到 $count 本书</span><br>";
            echo "<div style='background:#eaffea;border:1px solid green;padding:10px;margin:5px 0'>";
            echo "🎉 <strong>正确配置：</strong><br>";
            echo "方法：$method <br>";
            echo "结果预览：" . substr($res['body'], 0, 100) . "...";
            echo "</div>";
        } else {
            echo "<span style='color:orange'>⚠️ HTTP 200 但无数据 (可能是空结果)</span><br>";
        }
    } else {
        echo "<span style='color:red'>❌ 失败 (HTTP " . $res['code'] . ")</span><br>";
    }
}
?>