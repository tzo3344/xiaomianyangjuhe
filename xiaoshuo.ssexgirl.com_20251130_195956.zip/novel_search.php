<?php
// novel_search.php - 小说聚合搜索 (复刻版 UI)
require $_SERVER['DOCUMENT_ROOT'] . '/core/db.php';

// 获取所有小说源
$sources = [];
$res = $conn->query("SELECT * FROM collect_sources WHERE type='novel' ORDER BY id ASC");
while ($row = $res->fetch_assoc()) {
    $sources[] = $row;
}
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>全网搜书</title>
    <link href="https://cdn.staticfile.org/bootstrap/5.1.3/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.staticfile.org/bootstrap-icons/1.8.1/font/bootstrap-icons.min.css">
    
    <style>
        body { 
            background: linear-gradient(120deg, #e0f2f1 0%, #e3f2fd 100%); 
            font-family: "PingFang SC", sans-serif; color: #333; min-height: 100vh;
        }
        
        /* 容器 */
        .search-wrapper {
            max-width: 700px; margin: 0 auto; padding: 20px;
            display: flex; flex-direction: column; min-height: 80vh; justify-content: center;
        }
        /* 搜索后靠上 */
        .search-wrapper.has-result { justify-content: flex-start; margin-top: 20px; min-height: auto; }

        /* LOGO */
        .logo-area { text-align: center; margin-bottom: 40px; transition: 0.3s; }
        .logo-icon { font-size: 60px; color: #0d6efd; text-shadow: 0 10px 20px rgba(13,110,253,0.2); }
        .logo-title { font-size: 24px; font-weight: bold; margin-top: 10px; color: #333; }
        
        /* 搜索框 (大圆角) */
        .search-box {
            background: #fff; border-radius: 50px; padding: 8px 8px 8px 25px;
            box-shadow: 0 10px 40px rgba(13, 110, 253, 0.15); display: flex; align-items: center;
            border: 2px solid transparent; transition: 0.3s;
        }
        .search-box:focus-within { border-color: #0d6efd; transform: scale(1.02); }
        .search-input { border: none; width: 100%; outline: none; font-size: 16px; color: #333; }
        .search-btn {
            border-radius: 50px; padding: 12px 30px; border: none;
            background: linear-gradient(135deg, #0d6efd, #6ea8fe); color: white; font-weight: bold;
            box-shadow: 0 5px 15px rgba(13, 110, 253, 0.3); transition: 0.3s;
        }
        .search-btn:active { transform: scale(0.95); }

        /* 源切换 (Tab) */
        .source-tabs { 
            display: flex; justify-content: center; flex-wrap: wrap; gap: 10px; margin-top: 30px; 
        }
        .source-radio { display: none; }
        .source-label {
            background: rgba(255,255,255,0.6); padding: 8px 20px; border-radius: 20px;
            font-size: 13px; color: #666; cursor: pointer; transition: 0.3s; border: 1px solid rgba(255,255,255,0.5);
        }
        .source-radio:checked + .source-label {
            background: #0d6efd; color: #fff; box-shadow: 0 5px 15px rgba(13, 110, 253, 0.25); transform: translateY(-2px);
        }

        /* 结果列表 */
        .result-area { margin-top: 40px; display: none; }
        .book-card {
            background: #fff; border-radius: 16px; padding: 15px; margin-bottom: 15px;
            display: flex; gap: 15px; transition: 0.3s; border: 1px solid #fff;
            box-shadow: 0 5px 20px rgba(0,0,0,0.03); cursor: pointer; text-decoration: none; color: inherit;
        }
        .book-card:hover { transform: translateY(-5px); box-shadow: 0 10px 30px rgba(13, 110, 253, 0.1); }
        
        .book-cover { width: 70px; height: 95px; border-radius: 8px; object-fit: cover; background: #eee; flex-shrink: 0; }
        .book-info { flex: 1; min-width: 0; }
        .book-title { font-size: 16px; font-weight: bold; margin-bottom: 5px; color: #333; }
        .book-author { font-size: 12px; color: #888; margin-bottom: 8px; }
        .book-desc { font-size: 13px; color: #666; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; line-height: 1.5; }

        /* 加载动画 */
        .loading { text-align: center; margin-top: 50px; display: none; }
        .spinner-border { width: 3rem; height: 3rem; color: #0d6efd; }
    </style>
</head>
<body>

<div class="search-wrapper" id="main-box">
    
    <div class="logo-area" id="logo-area">
        <div class="logo-icon"><i class="bi bi-book-half"></i></div>
        <div class="logo-title">全网聚合搜书</div>
    </div>

    <div class="search-box">
        <input type="text" class="search-input" id="keyword" placeholder="请输入书名，例如：诡秘之主">
        <button class="search-btn" onclick="doSearch()">搜 索</button>
    </div>

    <div class="source-tabs">
        <?php foreach ($sources as $index => $src): ?>
            <input type="radio" name="source" id="s_<?php echo $src['id']; ?>" value="<?php echo $src['id']; ?>" class="source-radio" <?php echo $index==0?'checked':''; ?>>
            <label for="s_<?php echo $src['id']; ?>" class="source-label"><?php echo $src['name']; ?></label>
        <?php endforeach; ?>
        
        <?php if(empty($sources)): ?>
            <p class="text-muted small">暂无源，请去后台添加带规则的源</p>
        <?php endif; ?>
    </div>

    <div class="loading" id="loading">
        <div class="spinner-border" role="status"></div>
        <p class="mt-3 text-muted small">正在全力搜索中...</p>
    </div>

    <div class="result-area" id="result-area">
        </div>

</div>

<script>
    function doSearch() {
        const keyword = document.getElementById('keyword').value;
        const sourceId = document.querySelector('input[name="source"]:checked').value;
        
        if (!keyword) { alert('请输入关键词'); return; }

        // UI 切换状态
        document.getElementById('main-box').classList.add('has-result');
        document.getElementById('logo-area').style.display = 'none'; // 隐藏大Logo
        document.getElementById('loading').style.display = 'block';
        document.getElementById('result-area').style.display = 'none';
        document.getElementById('result-area').innerHTML = '';

        // 发起请求
        fetch(`api/spider.php?wd=${encodeURIComponent(keyword)}&source_id=${sourceId}`)
            .then(res => res.json())
            .then(data => {
                document.getElementById('loading').style.display = 'none';
                document.getElementById('result-area').style.display = 'block';

                if (data.code === 200 && data.list.length > 0) {
                    let html = '';
                    data.list.forEach(book => {
                        html += `
                            <a href="detail_spider.php?url=${encodeURIComponent(book.vod_id)}&source_id=${book.source_id}" class="book-card">
                                <img src="${book.vod_pic || ''}" class="book-cover" onerror="this.style.background='#eee'">
                                <div class="book-info">
                                    <div class="book-title">${book.vod_name}</div>
                                    <div class="book-author"><i class="bi bi-person"></i> ${book.vod_actor || '未知'}</div>
                                    <div class="book-desc">${book.vod_content || '暂无简介，点击阅读详情...'}</div>
                                </div>
                            </a>
                        `;
                    });
                    document.getElementById('result-area').innerHTML = html;
                } else {
                    document.getElementById('result-area').innerHTML = `<div class="text-center text-muted p-5">未搜索到相关内容<br>请尝试切换上面的源重新搜索</div>`;
                }
            })
            .catch(err => {
                document.getElementById('loading').style.display = 'none';
                alert('搜索出错，请检查网络或源配置');
            });
    }

    // 回车搜索
    document.getElementById('keyword').addEventListener('keypress', function (e) {
        if (e.key === 'Enter') doSearch();
    });
</script>

</body>
</html>